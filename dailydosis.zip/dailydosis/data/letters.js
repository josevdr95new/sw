// Letters data for DailyDosis app

export const letters = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ".split('');

